#include "stm32f10x.h"
#include "epaper.h" 
#include "picture.h"
ErrorStatus HSEStartUpStatus;

/* Private function prototypes -----------------------------------------------*/
void RCC_Configuration(void);
void NVIC_Configuration(void);
void GPIO_Configuration(void);



/////////////////////main//////////////////////////////////////
int main(void)
{
	#ifdef DEBUG
	  debug();
	#endif
	RCC_Configuration();
	//GPIO setting
	GPIO_Configuration();
	 
///////////////////////////////////////////
//  ȫˢ��ʽˢ������ͼƬ��4�ҽף�
		EPD_HW_Init_4GRAY(); 										//EPD init 4Gray
	 	EPD_WhiteScreen_ALL_4GRAY(gImage_4Gray11); 	
    driver_delay_xms(2000);				
	 
///////////////////////////////////////////
	  //ȫ��ˢ������ͼƬ���޻ҽף�
	  //Full screen refresh
		EPD_HW_Init(); 													//Electronic paper initialization
	 	EPD_WhiteScreen_ALL(gImage_1); 					//Refresh the picture in full screen
    driver_delay_xms(1000);
/*	
		EPD_HW_Init(); 													//Electronic paper initialization
	 	EPD_WhiteScreen_ALL(gImage_2); 					//Refresh the picture in full screen
    driver_delay_xms(1000);

		EPD_HW_Init(); 													//Electronic paper initialization
	 	EPD_WhiteScreen_ALL(gImage_3); 					//Refresh the picture in full screen
    driver_delay_xms(1000);

		EPD_HW_Init(); 													//Electronic paper initialization
	 	EPD_WhiteScreen_ALL(gImage_4); 					//Refresh the picture in full screen
    driver_delay_xms(1000);
		
		EPD_HW_Init(); 													//Electronic paper initialization
	 	EPD_WhiteScreen_ALL(gImage_5); 					//Refresh the picture in full screen
    driver_delay_xms(1000);

		EPD_HW_Init(); 													//Electronic paper initialization
	 	EPD_WhiteScreen_ALL(gImage_6); 					//Refresh the picture in full screen
    driver_delay_xms(1000);
*/	
		EPD_HW_Init(); 													//Electronic paper initialization	
		EPD_SetRAMValue_BaseMap(gImage_base);  	//Partial refresh background��ע�⣺�˴�ˢ����ͼƬ�ĺ�����ȫˢͼƬ�ĺ�����һ����
		driver_delay_xms(500);

///////////////////////////////////////////
//�����϶ȡ����ԣ�51.9��C������3��

//ע�⣺����ͼƬˢ�µ�ʱ�����ݷ�����ֱ��ִ�� EPD_Part_Update();
//      ���ͼ��һ��ˢ�µ�ʱ����������ȫ��������ϣ�һ����ִ�� EPD_Part_Update();
//�˴��������������ʾ�Ĳ��֣��ٷ�����Ҫ��ʾ�Ĳ��֣�������Ϊǰ��˳�������ɸ���ʾ�Ĳ���

		EPD_HW_Init(); 													//Electronic paper initialization
																											//    y         x       ��ʾ����     ��ʾ����     ��ʾ�߶�     ��ʾģʽ
		EPD_Dis_Part(25,104,gImage_Celsius,47,16,NEG); 		//   25       104        ���϶�         47           16				   ����

		EPD_Dis_Part(29,32,gImage_minus1,33,64,OFF); 		  //   29        32          -1           33           64					 OFF
		EPD_Dis_Part(75,32,gImage_num5,33,64,POS); 		    //   75        32           5           33           64					 ����
		EPD_Dis_Part(120,32,gImage_num1,33,64,POS);		    //  120        32           1           33           64					 ����
		EPD_Dis_Part(160,88,gImage_DOT,8,8,POS);		      //  160        88        С����          8            8					 ����
		EPD_Dis_Part(175,32,gImage_num9,33,64,POS); 	    //  175        32           9           33           64					 ����
		EPD_Dis_Part(221,32,gImage_degree,10,16,POS);     //  221        32           ��           10           16			     ����		
		EPD_Dis_Part(233,32,gImage_C,33,64,POS); 			    //  233        32           C           33           64					 ����
		EPD_Dis_Part(243,16,black_block,4,8,OFF);		      //  243        16      ������߸�        4            8				   OFF

		EPD_Part_Update_and_DeepSleep();
    driver_delay_xms(500);		


///////////////////////////////////////////
//�����϶ȡ����ԣ�125.4��F������3��

//���þ�ˢ��ʽ����ˢ�¶����ʾ�����ʱ�򣬴�����״̬����ֻ��ҪӲ����λ�Ϳ��ԣ��������³�ʼ����

		EPD_W21_Init();											    //hard reset
																											//    y         x       ��ʾ����     ��ʾ����     ��ʾ�߶�     ��ʾģʽ
		EPD_Dis_Part(25,104,gImage_Celsius,47,16,POS); 		//   25       104        ���϶�         47           16				   ����
		EPD_Dis_Part(92,104,gImage_Fahrenheit,47,16,NEG); //   92       104        ���϶�         47           16			     ����
		EPD_Dis_Part(25,104,gImage_Fahrenheit,47,16,POS); //   92       104        ���϶�         47           16			     ����
		
		EPD_Dis_Part(29,32,gImage_num1,33,64,POS); 		    //   29        32           1           33           64					 ����
		EPD_Dis_Part(75,32,gImage_num2,33,64,POS); 		    //   75        32           2           33           64					 ����
		EPD_Dis_Part(120,32,gImage_num5,33,64,POS);		    //  120        32           5           33           64					 ����
		EPD_Dis_Part(160,88,gImage_DOT,8,8,POS);		      //  160        88        С����          8            8					 ����
		EPD_Dis_Part(175,32,gImage_num4,33,64,POS); 	    //  175        32           4           33           64					 ����
		EPD_Dis_Part(221,32,gImage_degree,10,16,POS);     //  221        32           ��           10           16				   ����	
		EPD_Dis_Part(233,32,gImage_F,33,64,POS); 			    //  233        32           F           33           64					 ����
		EPD_Dis_Part(243,16,black_block,4,8,OFF);		      //  243        16      ������߸�        4            8				   OFF

		EPD_Part_Update_and_DeepSleep();
    driver_delay_xms(500);		
		
		
//////////////////////////////////////////
//��ʪ�ȡ����ԣ�30.6%������2��

		EPD_W21_Init();											    //hard reset
																											//    y         x       ��ʾ����     ��ʾ����     ��ʾ�߶�     ��ʾģʽ		
		EPD_Dis_Part(25,104,gImage_Celsius,47,16,POS); 		//   25       104        ���϶�         47           16				   ����
		EPD_Dis_Part(92,104,gImage_Fahrenheit,47,16,POS); //   92       104        ���϶�         47           16			     ����
		EPD_Dis_Part(159,104,gImage_humidity,47,16,NEG); 	//  159       104         ʪ��          47           16				   ����
		EPD_Dis_Part(25,104,gImage_humidity,47,16,NEG); 	//  159       104         ʪ��          47           16				   ����

		EPD_Dis_Part(29,32,gImage_num1,33,64,OFF); 		    //   29        32           1           33           64					 OFF
		EPD_Dis_Part(75,32,gImage_num3,33,64,POS); 		 		//   75        32           3           33           64					 ����
		EPD_Dis_Part(120,32,gImage_num0,33,64,POS);			  //  120        32           0           33           64					 ����
		EPD_Dis_Part(160,88,gImage_DOT,8,8,POS);		      //  160        88        С����          8            8					 ����
		EPD_Dis_Part(175,32,gImage_num6,33,64,POS); 			//  175        32           6           33           64					 ����
  	EPD_Dis_Part(221,32,gImage_degree,10,16,OFF);     //  221        32           ��           10           16				   OFF	
		EPD_Dis_Part(233,32,gImage_F,33,64,OFF); 			    //  233        32           F           33           64					 OFF
		EPD_Dis_Part(223,32,gImage_Percent,44,64,POS); 		//  223        32           %           44           64					 ����
		EPD_Dis_Part(243,16,black_block,4,8,OFF);		      //  243        16      ������߸�        4            8				   OFF
		EPD_Dis_Part(248,16,black_block,4,8,OFF);		      //  248        16      �����ڶ���        4            8				   OFF
		
		EPD_Part_Update_and_DeepSleep();
    driver_delay_xms(500);				


//////////////////////////////////////////
//�����������ԣ�72.8%������3��

		EPD_W21_Init();											//hard reset
																											//    y         x       ��ʾ����     ��ʾ����     ��ʾ�߶�     ��ʾģʽ		
		EPD_Dis_Part(25,104,gImage_Celsius,47,16,POS); 		//   25       104        ���϶�         47           16				   ����
		EPD_Dis_Part(92,104,gImage_Fahrenheit,47,16,POS); //   92       104        ���϶�         47           16			     ����
		EPD_Dis_Part(159,104,gImage_humidity,47,16,POS); 	//  159       104         ʪ��          47           16				   ����
		EPD_Dis_Part(226,104,gImage_Power,47,16,NEG); 		//  226       104         ����          47           16				   ����
		EPD_Dis_Part(25,104,gImage_Power,47,16,POS); 		//  226       104         ����          47           16				   ����

		EPD_Dis_Part(29,32,gImage_num1,33,64,OFF); 		    //   29        32           1           33           64					 OFF
		EPD_Dis_Part(75,32,gImage_num7,33,64,POS); 		 		//   75        32           7           33           64					 ����
		EPD_Dis_Part(120,32,gImage_num2,33,64,POS);			  //  120        32           2           33           64					 ����
		EPD_Dis_Part(160,88,gImage_DOT,8,8,POS);		      //  160        88        С����          8            8					 ����
		EPD_Dis_Part(175,32,gImage_num8,33,64,POS); 			//  175        32           8           33           64					 ����
  	EPD_Dis_Part(221,32,gImage_degree,10,16,OFF);     //  221        32           ��           10           16				   OFF
		EPD_Dis_Part(233,32,gImage_F,33,64,OFF); 			    //  233        32           F           33           64					 OFF
		EPD_Dis_Part(223,32,gImage_Percent,44,64,POS); 		//  223        32           %           44           64					 ����
		EPD_Dis_Part(243,16,black_block,4,8,OFF);		      //  243        16      ������߸�        4            8				   OFF
		EPD_Dis_Part(248,16,black_block,4,8,OFF);		      //  248        16      �����ڶ���        4            8				   OFF

		EPD_Part_Update_and_DeepSleep();				
    driver_delay_xms(500);				


///////////////////////////////////////////
//ע�⣺�Ӿ�ˢ��ʽת��ȫˢ��ʽ��ʱ�����ߺ�һ��Ҫ���³�ʼ��

		EPD_HW_Init(); 																		//Electronic paper initialization
		EPD_WhiteScreen_White();  												//Show all white

///////////////////////////////////////////
//////////////////////Partial screen refresh/////////////////////////////////////

		EPD_HW_Init(); //Electronic paper initialization	
		
	  EPD_Dis_Part(0,0,gImage_1,296,128,POS); 					//y,x,gImage_1,Resolution 296*128
		EPD_Part_Update_and_DeepSleep();	
	  driver_delay_xms(500);	

///////////////////////////////////////////

		EPD_W21_Init();											//hard reset
		
		EPD_Dis_Part(0,0,gImage_base,296,128,POS);        //y,x,gImage_base,Resolution 296*128
		EPD_Part_Update_and_DeepSleep();			
    driver_delay_xms(500);			
		
////////////////////////////////////////////////////////////////////////	
////////////////////////////////////////////////////////////////////////	
		//Clear screen

		EPD_HW_Init(); 																		//Electronic paper initialization
		EPD_WhiteScreen_White();  												//Show all white

		while(1);		

}
//ע�⣺��Ļˢ����ϱ���������ߡ�
///////////////////////////////////////////////////////////





/*******************************************************************************
* Function Name  : RCC_Configuration
* Description    : Configures the different system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RCC_Configuration(void)
{
 
  // Reset RCC clock configuration
  RCC_DeInit();
 
  // Enable external crystal
  RCC_HSEConfig(RCC_HSE_ON);
  
  // Waiting for the external crystal to stabilize
  HSEStartUpStatus = RCC_WaitForHSEStartUp();
  if(HSEStartUpStatus == SUCCESS)
  {
    // Set the phase-locked loop frequency PLLCLK = 8MHz * 9 = 72 MHz
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
  }
  else {
    // Enable internal crystal
    RCC_HSICmd(ENABLE);
    // Waiting for the internal crystal to stabilize
    while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET);

    // Set the phase-locked loop frequency PLLCLK = 8MHz/2 * 16 = 64 MHz 
    RCC_PLLConfig(RCC_PLLSource_HSI_Div2,RCC_PLLMul_16);
  }

    // Enable flash prefetch cache
  FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

  //Set the code delay, FLASH_Latency_2 is two delay cycles
  FLASH_SetLatency(FLASH_Latency_2);
	
  //Set the system total clock
  RCC_HCLKConfig(RCC_SYSCLK_Div1); 

  //Set the high speed device total clock, RCC_HCLK_Div1 is the system clock divided by 1
  RCC_PCLK2Config(RCC_HCLK_Div1); 

  //Set the low speed device total clock, RCC_HCLK_Div2 is the system clock divided by 2
  RCC_PCLK1Config(RCC_HCLK_Div2);
  
  //Enable phase-locked loop multiplier
  RCC_PLLCmd(ENABLE);
  
  // Waiting for the frequency of the phase-locked loop to multiply after frequency stabilization
  while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
  
  // Select the phase-locked loop clock as the system clock
  RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
  
  // Waiting for setup to complete
  while(RCC_GetSYSCLKSource() != 0x08);
    
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |
            RCC_APB2Periph_USART1|RCC_APB2Periph_AFIO,
            ENABLE);

}

/*******************************************************************************
* Function Name  :  GPIO_Configuration
* Description    : Configures the different system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void GPIO_Configuration(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
 	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE, ENABLE);//ʹ��PD��E�˿�ʱ��
	  				     	
	
	 //CS-->PD8   SCK-->PD9  SDO--->PD10 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10;		//Port configuration
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 		
	GPIO_Init(GPIOD, &GPIO_InitStructure);	  	
	
	
	
	 // D/C--->PE15	   RES-->PE14
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14|GPIO_Pin_15;		//Port configuration
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 		
	GPIO_Init(GPIOE, &GPIO_InitStructure);	  				     		
	
	// BUSY--->PE13
	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //Floating input
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
  GPIO_Init(GPIOE, &GPIO_InitStructure);    //Initialize GPIO
	
	 //LED
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;		//Port configuration
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 			
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 		
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}

/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures Vector Table base location.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{ 
  //NVIC_InitTypeDef NVIC_InitStructure;
  ;
}


#ifdef  DEBUG
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif






